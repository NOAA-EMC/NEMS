var documentation =
[
    [ "Introduction to NEMS", "introduction.html", null ],
    [ "Architecture", "architecture.html", null ],
    [ "Repository Structure and Versioning", "structure.html", null ],
    [ "Compiling: NEMSAppBuilder and GNUmakefile", "building.html", null ],
    [ "Configuring", "configuring.html", null ],
    [ "Running: NEMSCompsetRun", "running.html", null ],
    [ "Mediator Reference", "mediator.html", null ],
    [ "Cap Documentation", "cap-page.html", null ]
];