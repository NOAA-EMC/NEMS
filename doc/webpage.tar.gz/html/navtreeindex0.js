var NAVTREEINDEX0 =
{
"architecture.html":[0,1],
"building.html":[0,3],
"cap-page.html":[0,7],
"configuring.html":[0,4],
"documentation.html":[0],
"index.html":[],
"introduction.html":[0,0],
"links.html":[1],
"mediator.html":[0,6],
"pages.html":[],
"running.html":[0,5],
"structure.html":[0,2]
};
