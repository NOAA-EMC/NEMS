var searchData=
[
  ['architecture',['Architecture',['../architecture.html',1,'documentation']]]
];
